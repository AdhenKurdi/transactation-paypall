-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 23, 2023 at 01:17 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `transaksii`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `id_barang` int(11) NOT NULL,
  `nama_barang` varchar(255) NOT NULL,
  `harga` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id_barang`, `nama_barang`, `harga`) VALUES
(1, 'Beras', '20000'),
(2, 'Minyak', '10000');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `product_id` float(10,2) NOT NULL,
  `transaction_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `payment_amount` float(10,2) NOT NULL,
  `currency_code` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `payment_status` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `invoice_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `product_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `createdtime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `product_id`, `transaction_id`, `payment_amount`, `currency_code`, `payment_status`, `invoice_id`, `product_name`, `createdtime`) VALUES
(0, 1.00, 'PAYID-MUHKKWQ77G39980NG977324G', 20000.00, 'USD', 'approved', '650ea5e3be6f5', 'Beras', '2023-09-23 10:46:51'),
(0, 1.00, 'PAYID-MUHLLMI20937741X8628172D', 20000.00, 'USD', 'approved', '650eb639d9ee8', 'Beras', '2023-09-23 11:56:31'),
(0, 1.00, 'PAYID-MUHLUQY48H12719285274408', 20000.00, 'USD', 'approved', '650ebacc7aed2', 'Beras', '2023-09-23 12:16:00'),
(0, 1.00, 'PAYID-MUHL6JY8EH1279263281562G', 40000.00, 'USD', 'approved', '650ebfb04bd2a', 'Beras', '2023-09-23 12:36:51'),
(0, 21.00, 'PAYID-MUHMLAQ51U63877AY3844344', 266.00, 'USD', 'approved', '650ec60bed26f', 'Beras', '2023-09-23 13:04:04');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` int(11) NOT NULL,
  `id_barang` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `id_barang`, `id_user`, `jumlah`, `created_at`) VALUES
(1, 1, 2, 2, '2023-09-19 11:29:52'),
(2, 2, 1, 5, '2023-09-19 11:29:52'),
(3, 1, 1, 5, '2023-09-19 11:49:06'),
(4, 1, 1, 10, '2023-09-19 11:54:58'),
(5, 2, 1, 4, '2023-09-19 11:58:27'),
(6, 2, 2, 7, '2023-09-20 11:51:54'),
(7, 2, 1, 1, '2023-09-20 14:33:02'),
(8, 1, 1, 1, '2023-09-20 17:35:46'),
(9, 2, 2, 1, '2023-09-21 10:17:42'),
(10, 2, 1, 12, '2023-09-21 13:02:13'),
(11, 1, 1, 2, '2023-09-21 13:17:20'),
(12, 2, 2, 10, '2023-09-21 13:17:29'),
(13, 1, 1, 1, '2023-09-22 19:03:15'),
(14, 1, 1, 1, '2023-09-23 04:52:25'),
(15, 2, 2, 15, '2023-09-23 10:58:08'),
(16, 2, 2, 15, '2023-09-23 10:58:32'),
(17, 1, 1, 20, '2023-09-23 10:58:44'),
(20, 1, 1, 100, '2023-09-23 11:01:43'),
(21, 1, 1, 200, '2023-09-23 11:03:36');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nama_user` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `nama_user`) VALUES
(1, 'Surya'),
(2, 'Juki');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id_barang`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD KEY `id_barang` (`id_barang`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `barang`
--
ALTER TABLE `barang`
  MODIFY `id_barang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`id_barang`) REFERENCES `barang` (`id_barang`),
  ADD CONSTRAINT `transaksi_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
