<?php 
include_once 'db_connection.php';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Daftar Transaksi</title>
    <!-- <link rel="stylesheet" type="text/css" href="style.css"> -->
</head>
<body class="App">
  <h1>Daftar Transaksi</h1>
  <table>
    <head>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table, th, td {
            border: 1px solid #ccc;
        }

        th, td {
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        th, td {
            white-space: nowrap;
        }

        .add-button {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
        }

        .add-button:hover {
            background-color: #0056b3;
        }
    </style>
        <tr>
            <th>ID Transaksi</th>
            <th>Nama Barang</th>
            <th>Nama User</th>
            <th>Jumlah</th>
            <th>Harga</th>
            <th>Subtotal</th>
            <th>Tanggal Transaksi</th>
            <th>Action</th>
        </tr>
    </head>
    <tbody>
        <?php 
        $results = mysqli_query($db_conn,"SELECT transaksi.id_transaksi, barang.nama_barang, users.nama_user, transaksi.jumlah, barang.harga, transaksi.created_at
        FROM transaksi
        JOIN barang ON transaksi.id_barang = barang.id_barang
        JOIN users ON transaksi.id_user = users.id
        ORDER BY transaksi.id_transaksi ASC");
        $total = 0;
        while($row = mysqli_fetch_array($results)){
            $jumlah = $row["jumlah"];
            $harga = $row["harga"];
            $subtotal = $jumlah * $harga;
            $total += $subtotal;
            $result = $subtotal /15000;
            
        ?>
        <tr>
            <td><?php echo $row['id_transaksi'] ; ?></td>
            <td><?php echo $row['nama_barang']; ?></td>
            <td><?php echo $row['nama_user']; ?></td>
            <td><?php echo $row['jumlah']; ?></td>
            <td><?php echo $row['harga']; ?></td>
            <td><?php echo $subtotal; ?></td>
            <td><?php echo $row["created_at"]; ?></td>
            <td>
                <form class="paypal" action="request.php" method="post" id="paypal_form">
                    <input type="hidden" name="item_number" value="<?php echo $row['id_transaksi']; ?>" >
                    <input type="hidden" name="item_name" value="<?php echo $row['nama_barang']; ?>" >
                    <input type="hidden" name="amount" value="<?php echo intval($result); ?>" >
                    <input type="hidden" name="currency_code" value="USD" >
                    <input type="submit" name="submit" value="Bayar" class="btn__default">
                </form>
            </td>
        </tr>
        <?php } ?>
    </tbody>
  </table>
  <p><button class="add-button" onclick="location.href='tambah_transaksi_form.php'">Tambah Transaksi</button></p>
</body>
</html>
